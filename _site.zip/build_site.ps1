# 切换到脚本所在目录（避免路径问题）
Set-Location $PSScriptRoot

Write-Host "==============================" -ForegroundColor Cyan
Write-Host "Building Jekyll site..." -ForegroundColor Cyan
Write-Host "==============================" -ForegroundColor Cyan

bundle exec jekyll clean
if ($LASTEXITCODE -ne 0) { throw "jekyll clean failed" }

bundle exec jekyll build
if ($LASTEXITCODE -ne 0) { throw "jekyll build failed" }

Write-Host "`n Build finished successfully!" -ForegroundColor Green
Write-Host "Output directory: _site"
Read-Host "Press Enter to exit"
